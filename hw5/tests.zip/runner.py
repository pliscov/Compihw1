import os.path
import subprocess

EXEC = './hw5'
files = [
    "./students_tests_regular/test13.in",
    "./students_tests_regular/test27.in",
    "./students_tests_regular/test66.in",
    "./students_tests_regular/test52.in",
    "./students_tests_regular/test72.in",
    "./students_tests_regular/test17.in",
    "./students_tests_regular/test4.in",
    "./students_tests_regular/test56.in",
    "./students_tests_regular/test62.in",
    "./students_tests_regular/test16.in",
    "./students_tests_regular/test47.in",
    "./students_tests_regular/test5.in",
    "./students_tests_regular/test57.in",
    "./students_tests_regular/test43.in",
    "./students_tests_regular/test12.in",
    "./students_tests_regular/test26.in",
    "./students_tests_regular/test1.in",
    "./students_tests_regular/test67.in",
    "./students_tests_regular/test36.in",
    "./students_tests_regular/test53.in",
    "./students_tests_regular/test48.in",
    "./students_tests_regular/test19.in",
    "./students_tests_regular/test58.in",
    "./students_tests_regular/test29.in",
    "./students_tests_regular/test68.in",
    "./students_tests_regular/test28.in",
    "./students_tests_regular/test69.in",
    "./students_tests_regular/test18.in",
    "./students_tests_regular/test59.in",
    "./students_tests_regular/test21.in",
    "./students_tests_regular/test44.in",
    "./students_tests_regular/test15.in",
    "./students_tests_regular/test6.in",
    "./students_tests_regular/test54.in",
    "./students_tests_regular/test60.in",
    "./students_tests_regular/test11.in",
    "./students_tests_regular/test40.in",
    "./students_tests_regular/test74.in",
    "./students_tests_regular/test25.in",
    "./students_tests_regular/test2.in",
    "./students_tests_regular/test64.in",
    "./students_tests_regular/test41.in",
    "./students_tests_regular/test24.in",
    "./students_tests_regular/test65.in",
    "./students_tests_regular/test51.in",
    "./students_tests_regular/test20.in",
    "./students_tests_regular/test71.in",
    "./students_tests_regular/test45.in",
    "./students_tests_regular/test14.in",
    "./students_tests_regular/test7.in",
    "./students_tests_regular/test55.in",
    "./students_tests_regular/test61.in",
    "./students_tests_regular/test30.in",
    "./tests_segel/t06-div-zero.in",
    "./tests_segel/t08-extra-logic.in",
    "./tests_segel/t09-simple-while.in",
    "./tests_segel/t14-func-short-circuits.in",
    "./tests_segel/t11-nested-loops.in",
    "./tests_segel/t04-tricky-set-shadows.in",
    "./tests_segel/t16-control-flow-weirdness.in",
    "./tests_segel/t13-func-calls-rets.in",
    "./tests_segel/t10-vartests.in",
    "./tests_segel/t03.in",
    "./tests_segel/t1.in",
    "./tests_segel/t21-short-circuit-zerodiv.in",
    "./tests_segel/t2.in",
    "./tests_segel/t07-div-zero-computed.in",
    "./tests_segel/t05-bytes.in",
    "./tests_segel/t18-large-expressions.in",
    "./tests_segel/t17-more-weird-short-cc.in",
    "./tests_segel/t12-func-calls.in",
    "./tests_segel/t15-func-param-ordering.in",
    "./tests_segel/t19-large-expressions-more.in",
    "./students_tests_my_own/recursion_tests/t4.in",
    "./students_tests_my_own/recursion_tests/t1.in",
    "./students_tests_my_own/recursion_tests/t2.in",
    "./students_tests_my_own/recursion_tests/t3.in",
    "./students_tests_my_own/div_zero_tests/t4.in",
    "./students_tests_my_own/div_zero_tests/t5.in",
    "./students_tests_my_own/div_zero_tests/t1.in",
    "./students_tests_my_own/div_zero_tests/t2.in",
    "./students_tests_my_own/div_zero_tests/t3.in",
    "./students_tests_my_own/while_tests/while_3_break2.in",
    "./students_tests_my_own/while_tests/while_call_func_1.in",
    "./students_tests_my_own/while_tests/break_tests/break_in_else.in",
    "./students_tests_my_own/while_tests/break_tests/break_in_if.in",
    "./students_tests_my_own/while_tests/break_tests/OR_testBreakInnerWhile.in",
    "./students_tests_my_own/while_tests/while_4_nested.in",
    "./students_tests_my_own/while_tests/while_1_simple.in",
    "./students_tests_my_own/while_tests/while_2_break1.in",
    # "./students_tests_my_own/return_tests/t4.in", Bad test - changes func param
    "./students_tests_my_own/return_tests/t1.in",
    "./students_tests_my_own/return_tests/t2.in",
    "./students_tests_my_own/return_tests/t3.in",
    "./students_tests_my_own/bool_tests/bool_4_vars1.in",
    "./students_tests_my_own/bool_tests/bool_2_relops.in",
    "./students_tests_my_own/bool_tests/bool_6_complex2.in",
    "./students_tests_my_own/bool_tests/bool_5_complex.in",
    "./students_tests_my_own/bool_tests/bool_8.in",
    "./students_tests_my_own/bool_tests/bool_9.in",
    "./students_tests_my_own/bool_tests/bool_3_logops.in",
    "./students_tests_my_own/bool_tests/bool_7_as_func.in",
    "./students_tests_my_own/bool_tests/bool_1_consts.in",
    "./students_tests_my_own/if_test.in",
    "./students_tests_my_own/binop_test.in",
    "./students_tests_my_own/gcd_test1.in",
    "./students_tests_my_own/overflow_test1.in",
    "./students_tests_my_own/smart_reg_management/smart_reg_mng2.in",
    "./students_tests_my_own/smart_reg_management/smart_reg_mng3.in",
    "./students_tests_my_own/smart_reg_management/smart_reg_mng4.in",
    "./students_tests_my_own/smart_reg_management/smart_reg_mng1.in",
    "./students_tests_my_own/vars_params_tests/vars_test2.in",
    "./students_tests_my_own/vars_params_tests/shitloads_parameters.in",
    "./students_tests_my_own/vars_params_tests/vars_test1.in",
    "./course_tests/t1.in",
    "./course_tests/t2.in",


]
counter = 0


def test(file):
    file_data = None
    test_count = len(files)
    global counter
    print(f"Running: f{file}")
    with open(file, 'r') as f:
        file_data = f.read()
    llvm_code = subprocess.run([EXEC], input=file_data, capture_output=True, encoding='utf-8').stdout
    output = subprocess.run(['lli'], input=llvm_code, encoding='utf-8', capture_output=True)
    # Save output
    output_path = os.path.join(os.path.dirname(file), os.path.basename(file) + '.mine')
    with open(output_path, 'w') as f:
        f.write(output.stdout)

    # Compare with known out
    output_refernce_path = file.replace(".in", ".out")
    diff_out = subprocess.run(['diff', '--brief', output_refernce_path, output_path], capture_output=True,
                              encoding='utf-8')
    print(diff_out.stdout, end="")
    if len(diff_out.stdout) == 0:
        counter += 1


[test(file) for file in files]
print(f"SAME: {counter} of TOTAL: {len(files)}")
